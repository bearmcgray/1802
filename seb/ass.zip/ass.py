import sys

regs=["R0","R1","R2","R3","R4","R5","R6","R7","R8","R9","RA","RB","RC","RD","RE","RF"]

linetypes={
	"error":{"char":"", "code":0},
	"comment":{"char":";", "code":100},
	"preproc":{"char":".", "code":10},
	"op":{"char":"", "code":1},
	"label":{"char":":", "code":2},
}

preproc = {
	".org":{"params":1},
	".equ":{"params":2},
	".db":{"params":-1},
	".include":{"params":1},
}

op = {
	"idl":{"code":0x00,"mask":0x0f,"params":1,"next":0},
	
	"inc":{"code":0x10,"mask":0x0f,"params":1,"next":0},
	"dec":{"code":0x20,"mask":0x0f,"params":1,"next":0},

	"b":{"code":0x30,"mask":0x00,"params":1,"next":1},
	"bne":{"code":0x31,"mask":0x00,"params":1,"next":1},
	"beq":{"code":0x32,"mask":0x00,"params":1,"next":1},
	"bdf":{"code":0x33,"mask":0x00,"params":1,"next":1},
	
	"b1":{"code":0x34,"mask":0x00,"params":1,"next":1},
	"b2":{"code":0x35,"mask":0x00,"params":1,"next":1},
	"b3":{"code":0x36,"mask":0x00,"params":1,"next":1},
	"b4":{"code":0x37,"mask":0x00,"params":1,"next":1},

	"lda":{"code":0x40,"mask":0x0f,"params":1,"next":0},
	"str":{"code":0x50,"mask":0x0f,"params":1,"next":0},
	
	"inp":{"code":0x68,"mask":0x00,"params":0,"next":0},
	
	"ret":{"code":0x70,"mask":0x00,"params":0,"next":0},
	"sav":{"code":0x78,"mask":0x00,"params":0,"next":0},
	
	"glo":{"code":0x80,"mask":0x0f,"params":1,"next":0},
	"ghi":{"code":0x90,"mask":0x0f,"params":1,"next":0},

	"plo":{"code":0xA0,"mask":0x0f,"params":1,"next":0},
	"phi":{"code":0xB0,"mask":0x0f,"params":1,"next":0},

	"plolo":{"code":0xC0,"mask":0x0f,"params":1,"next":0},

	"sep":{"code":0xD0,"mask":0x0f,"params":1,"next":0},	
	"sex":{"code":0xE0,"mask":0x0f,"params":1,"next":0},

	"ldx":{"code":0xf0,"mask":0x00,"params":0,"next":0},
	"or":{"code":0xf1,"mask":0x00,"params":0,"next":0},
	"and":{"code":0xf2,"mask":0x00,"params":0,"next":0},
	"xor":{"code":0xf3,"mask":0x00,"params":0,"next":0},
	"add":{"code":0xf4,"mask":0x00,"params":0,"next":0},
	"sub":{"code":0xf5,"mask":0x00,"params":0,"next":0},
	"shr":{"code":0xf6,"mask":0x00,"params":0,"next":0},
	"spare":{"code":0xf7,"mask":0x00,"params":0,"next":0},
		
}

def line_clean(line):
	scp = line.find(linetypes["comment"]["char"])
	if scp>=0:
		line = line[:scp]
	return line.strip()

def line_segment(line):
	def first_other(line):
		fs = line.find(" ")
		if fs>=0:
			return (line[:fs],line[fs:].strip())
		else:	
			return (line,None)
			
	pp = line.find(linetypes["preproc"]["char"])
	lp = line.find(linetypes["label"]["char"])
	
	if pp>=0 and lp>=0:
		return (linetypes["error"]["code"], "syntax error")
	elif pp>=0:
		return (linetypes["preproc"]["code"], first_other(line))
	elif lp>=0:
		return (linetypes["label"]["code"], line[:lp])
	else:	
		return (linetypes["op"]["code"], first_other(line))
		
def line_validate():
	pass
	
class code:
	def __init__(self):
		self.__len = 16
		self.__code = [0]*self.__len
		self.__dirty = [0]*self.__len

	def add(self,addr,data):
		added=0
		
		if addr>=len(self.__code):
			tmpc=self.__code
			tmpd=self.__dirty
			
			self.__code = [0]*self.__len*2
			self.__dirty = [0]*self.__len*2
			for i in range(self.__len):
				self.__code[i]=tmpc[i]
				self.__dirty[i]=tmpd[i]
			self.__len*=2
		else:
			if self.__dirty[addr]:
				#~ pass
				raise RuntimeError("adress regions overlapped!!!")
			else:	
				self.__code[addr]=data
				self.__dirty[addr]=1
				added=1
				
		if not added:	
			self.add(addr,data)

	def get(self):
		return self.__code

def main():
	name = "tst.asm"
	
	PC=0
	LL={}
	DEFER={}
	EQU={}
	
	CODE = code()
	
	with open(name,"rt") as f:
		while 1:
			line = f.readline()
			if not line:
				break
			line = line_clean(line)
			if line:
				ls = line_segment(line)				
			
				if ls[0]==linetypes["preproc"]["code"]:
					if ls[1][0]==".org":
						PC=int(ls[1][1],16)
					if ls[1][0]==".db":
						n=ls[1][1]
						n=EQU.get(n,n)

						CODE.add(PC, int(n,16) )
						PC+=1
					if ls[1][0]==".equ":
						pv = ls[1][1].split()
						EQU[pv[0].strip()]=pv[1].strip()
						
				if ls[0]==linetypes["label"]["code"]:
					
					if LL.get(ls[1]):
						raise RuntimeError("multiple label!!!")
					else:
						LL[ls[1]]=PC
					
				if ls[0]==linetypes["op"]["code"]:
					arg = 0
					if ls[1][1]:
						n=ls[1][1]
						n=EQU.get(n,n)
							
						if n in regs:
							arg=int("0x"+n[1:],16)
						else:
							if not op[ls[1][0]]["next"]:
								raise RuntimeError("wrong arg!!! "+ls[1][1])
							else:
								pass

					CODE.add(PC, op[ls[1][0]]["code"]|(arg&op[ls[1][0]]["mask"]) )
					PC+=1
					
					if ls[1][0]=="b":
						if LL.get(ls[1][1]):
							CODE.add(PC, LL[ls[1][1]] )
						else:	
							if DEFER.get(ls[1][1]):
								DEFER[ls[1][1]].append(PC)
							else:	
								DEFER[ls[1][1]] = [PC]	
						PC+=1
						
	# populate defer
	for k,v in DEFER.items():
		for j in v:
			CODE.add(j, LL[k])
	
	print(CODE.get()) 
	
if __name__=="__main__":
	main()
