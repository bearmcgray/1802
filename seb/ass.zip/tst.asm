.include "hdr.asm"

.equ PC R0
.equ TMP R2
.equ OFS 0x30

.org 0x0
;main begins here
start:
	;b skip
	;dec R11
	;dec R12
	;dec R13
	;dec R14
	;b skip
;skip:
	
	glo R0
	lda PC
.db OFS
	plo TMP
	lda PC
.db 0x01
	phi TMP
	lda R0
.db 0x02
	str TMP

	sex TMP   ;haha
	b loop
	
.org 0x10	
loop:
	add
	b loop;loop there
	
	;b skip
	;ldi R0,4
	